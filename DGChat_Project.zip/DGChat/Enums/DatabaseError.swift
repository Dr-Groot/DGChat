//
//  DatabaseError.swift
//  DGChat
//
//  Created by Aman Pratap Singh on 05/10/23.
//

import Foundation

public enum DatabaseError: Error {
    case failedToFetch
}
